﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarPresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int choice;
                do
                {
                    Print();
                    Console.WriteLine("Enter your choice");
                    choice = Int32.Parse(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            AddcarPL();
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        case 2:
                            ModifycarPL();
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        case 3:
                            SearchcarPL();
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        case 4:
                            RemovePL();
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        case 5:
                            ShowallPL();
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        case 6:
                            return;
                        default:
                            Console.WriteLine("invalid choice");
                            break;
                    }

                } while (choice != -1);
            }
            catch (CarExcpt ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void AddcarPL()
        {
            CarEntities car = new CarEntities();
            try
            {
                Console.Clear();
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("                                 Add CAR Details                           ");
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("Enter Manufacturer Name");
                car.ManufacturerName = Console.ReadLine();
                Console.WriteLine("Enter Car Model");
                car.Model = Console.ReadLine();
                Console.WriteLine("Enter Car Type(Hatchback or Sedan or SUV)");
                car.Type = Console.ReadLine();
                Console.WriteLine("Enter Engine");
                car.Engine = Console.ReadLine();
                Console.WriteLine("Enter BHP");
                car.BHP = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Car Transmission (Manual/Automatic)");
                car.Transmission = Console.ReadLine();
                Console.WriteLine("Enter Mileage");
                car.Mileage = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter no. of seats");
                car.Seats = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Airbags details");
                car.Airbags = Console.ReadLine();
                Console.WriteLine("Enter BootSpace");
                car.BootSpace = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Price");
                car.price = double.Parse(Console.ReadLine());


                bool added = CarBL.AddBLL(car);
                if (added)
                    Console.WriteLine("Car Details are added successfully");
                else
                    Console.WriteLine("Details are not added ");
            }
            catch (CarExcpt ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void ModifycarPL()
        {
            string model;
            try
            {
                Console.Clear();
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("                                 Modify Car Details                           ");
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("Enter  car Model");
                model = Console.ReadLine();
                CarEntities car = CarBL.SearchBLL(model);
                if (car != null)
                {
                    Console.WriteLine("Enter Manufacturer Name");
                    car.ManufacturerName = Console.ReadLine();

                    Console.WriteLine("Enter Car Type(Hatchback or Sedan or SUV)");
                    car.Type = Console.ReadLine();
                    Console.WriteLine("Enter Engine");
                    car.Engine = Console.ReadLine();
                    Console.WriteLine("Enter BHP");
                    car.BHP = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Car Transmission (Manual/Automatic)");
                    car.Transmission = Console.ReadLine();
                    Console.WriteLine("Enter Mileage");
                    car.Mileage = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter no. of seats");
                    car.Seats = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Airbags details");
                    car.Airbags = Console.ReadLine();
                    Console.WriteLine("Enter BootSpace");
                    car.BootSpace = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Price");
                    car.price = double.Parse(Console.ReadLine());
                    bool modified = CarBL.ModifyBLL(car);
                    if (modified)
                        Console.WriteLine("Car Details are updated");
                    else
                        Console.WriteLine("Car Details are not updated");
                }
                else
                    Console.WriteLine("Model not found");
            }
            catch (CarExcpt ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SearchcarPL()
        {
            string model;
            CarEntities car;
            try
            {
                Console.Clear();
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("                                 Search car                           ");
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("Enter  car Model");
                model = Console.ReadLine();

                car = CarBL.SearchBLL(model);
                if (car != null)
                {
                    Console.WriteLine("Car is found");
                    Console.WriteLine("*****************************************************************************");
                    Console.WriteLine(car.ManufacturerName + "\t" + car.Model + "\t" + car.Type + "\t" + car.price);
                    Console.WriteLine("*****************************************************************************");

                }
                else
                    Console.WriteLine("Car not found");

            }
            catch (CarExcpt ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void RemovePL()
        {
            try
            {
                string model;
                Console.Clear();
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("                                 Remove Car Details                           ");
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("Enter  car Model");
                model = Console.ReadLine();
                Console.WriteLine(" Are you sure to delete \t" + model + "\tenter 1 for Yes or 2 for No");
                int x = int.Parse(Console.ReadLine());
                switch (x)
                {
                    case 1:
                        bool removedcar = CarBL.RemoveBLL(model);

                        if (removedcar)
                            Console.WriteLine("Car Details are removed successfully");
                        else
                            Console.WriteLine("Details are not removed as details are not found ");

                        break;
                    case 2:
                        break;
                    default:
                        Console.WriteLine("Invalid choice");
                        break;

                }
            }
            catch (CarExcpt ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        public static void ShowallPL()
        {
            List<CarEntities> carlist = new List<CarEntities>();
            try
            {
                Console.Clear();
                Console.WriteLine("************************************************************************************");
                Console.WriteLine("                                 Display All Cars                           ");
                Console.WriteLine("************************************************************************************");
                carlist = CarBL.ShowBLL();

                Console.WriteLine("*********************************************************************************");
                Console.WriteLine("ManufacturerName\tModel\tType\tPrice");
                Console.WriteLine("*********************************************************************************");
                foreach (CarEntities car in carlist)
                    Console.WriteLine(car.ManufacturerName + "\t" + car.Model + "\t" + car.Type + "\t" + car.price);

            }
            catch (CarExcpt ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void Print()
        {
            Console.WriteLine("************************************************************************************");
            Console.WriteLine("                                 Car Details                           ");
            Console.WriteLine("************************************************************************************");
            Console.WriteLine("1. Add Car ");
            Console.WriteLine("2. Modify car");
            Console.WriteLine("3. Search Car");
            Console.WriteLine("4. Remove car");
            Console.WriteLine("5. Show list");
            Console.WriteLine("6.Exit");
        }
    }
}

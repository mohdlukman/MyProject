﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarEntity;
using Car_Exception;

namespace CarDataAccessLayer
{
    public class CarDal
    {
        public static List<Car> Carlist = new List<Car>();
        public void AddCar(Car cars)
        { 
            try
            {
                Carlist.Add(cars);    

           }
            catch (CarException ce)
            {
                throw ce;
            }
            
       }
        public Car SearchCarDAL(string model)
        {
            Car carsearch;
            try
            {
                carsearch = Carlist.Find(car => car.Model == model);
            }
            catch (CarException ce)
            {
                throw ce;
            }
            return carsearch;
        }

        public void ModifyCarDAL(Car cars)
        {
            
            try
            {
                for (int i = 0; i < Carlist.Count; i++)
                {
                    if (Carlist[i].Model == cars.Model)
                    {
                        Carlist[i].ManufacturerName = cars.ManufacturerName;
                        Carlist[i].Mileage = cars.Mileage;
                        Carlist[i].price = cars.price;
                        Carlist[i].Seats = cars.Seats;
                        Carlist[i].BootSpace = cars.BootSpace;
                        Carlist[i].Airbags = cars.Airbags;
                        Carlist[i].BHP = cars.BHP;
                        Carlist[i].Engine = cars.Engine;
                        break;
                    }
                }
            }
            catch (CarException ce)
            {
                throw ce;
            }
        }

        public void RemoveCarDAL(string model)
        {try
            {
                Car deleteCar = Carlist.Find(car => car.Model == model);
                if (deleteCar != null)
                {
                    Carlist.Remove(deleteCar);
                }
            }
            catch (CarException ce)
            {
                throw ce;
            }
        }

        public List<Car> ShowDAL()
        {
            try
            {
               
                return Carlist;
            }
            catch (CarException ce)
            {
                throw ce;
            }
        }
       
    }
}
